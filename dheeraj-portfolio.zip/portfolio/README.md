# Dheeraj Soni Portfolio

## Run locally
1. Open `index.html` in VS Code.
2. Use Live Server, or double-click the file to open it in your browser.

## Update later
- Add your email in the Contact section.
- Replace/add project links when you have GitHub repositories ready.
- Add your resume button when your final resume PDF is ready.
